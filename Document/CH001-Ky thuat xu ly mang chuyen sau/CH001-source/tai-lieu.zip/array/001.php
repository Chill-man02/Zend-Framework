<?php
	$employee = array();
	$employee[] = "Nguyen Van A";
	$employee[] = "Nguyen Van B";
	$employee[] = "Nguyen Van C";