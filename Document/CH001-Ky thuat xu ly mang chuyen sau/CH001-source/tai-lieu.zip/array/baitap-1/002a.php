<?php

$group[] = array('id'=>1,'name'=>'Admin');
$group[] = array('id'=>2,'name'=>'Manager');
$group[] = array('id'=>3,'name'=>'Member');

echo "<pre>";
print_r($group);
echo "</pre>";
